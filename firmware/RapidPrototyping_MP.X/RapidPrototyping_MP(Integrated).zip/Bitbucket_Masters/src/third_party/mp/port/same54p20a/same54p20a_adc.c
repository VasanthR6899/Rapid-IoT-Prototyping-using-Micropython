

#include "same54p20a_adc.h"
#include "definitions.h"


#define ADC_VREF                (3.3f)
#define ADC_MAX_COUNT           (4095)



void adc_enable(int pin_id)
{

	switch (pin_id)
    {
        case 125:    /*AIN12*/
            
            ADC0_Enable();
            ADC0_ConversionStart();
            break;
            
        case 11:    /*AIN6*/
            
            ADC1_Enable();
            ADC1_ConversionStart();
            break;
            
        case 7:    /*AIN4*/
                 
            ADC1_REGS->ADC_INPUTCTRL = (uint16_t) ADC_POSINPUT_AIN4 | (uint16_t) ADC_NEGINPUT_GND ;
            ADC1_Enable();
            ADC1_ConversionStart();
            break;
          
        default:
            break;
    }  
    

}

uint16_t adc_read(EXT_NUM ext_num)
{

    uint16_t adc_count;
    if(ext_num == 1 || ext_num == 3)
    {
       
        while(ADC1_ConversionStatusGet());
            
        adc_count = ADC1_ConversionResultGet();
    
        ADC1_ConversionStart();

        return adc_count;
        
    }
    else if(ext_num == 2)
    {
                
        while(ADC0_ConversionStatusGet());
            
        adc_count = ADC0_ConversionResultGet();
    
        ADC0_ConversionStart();

        return adc_count;
        
    }
}

uint32_t adc_read_voltage(EXT_NUM ext_num)
{
    uint16_t adc_count;
    float input_voltage;
    
    if(ext_num == 1 || ext_num == 3)
    {
        ADC1_ConversionStart();
        
        while(ADC1_ConversionStatusGet());
    
        adc_count = ADC1_ConversionResultGet();

        input_voltage = adc_count* 1650 / 4095U;

        return input_voltage;
    
    }
    
    else if(ext_num == 2)
    {
        ADC0_ConversionStart();
        
        while(ADC0_ConversionStatusGet());
    
        adc_count = ADC0_ConversionResultGet();

        input_voltage = adc_count * ADC_VREF / ADC_MAX_COUNT * 1000000;
    
        return input_voltage;
    
    }
    
    
}
 