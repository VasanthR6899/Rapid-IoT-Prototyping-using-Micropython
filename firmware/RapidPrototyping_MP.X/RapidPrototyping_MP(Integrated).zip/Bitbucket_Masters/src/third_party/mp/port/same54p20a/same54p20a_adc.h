
#ifndef _SAME54_PY_ADC_

#define _SAME54_PY_ADC_

#include "definitions.h"

typedef enum
{
    EXT_NUM_1 = 1,
    EXT_NUM_2 = 2,
    EXT_NUM_3 = 3
} EXT_NUM;

void adc_enable(int pin_id);
uint16_t adc_read(EXT_NUM ext_num);
uint32_t adc_read_voltage(EXT_NUM ext_num);

#endif